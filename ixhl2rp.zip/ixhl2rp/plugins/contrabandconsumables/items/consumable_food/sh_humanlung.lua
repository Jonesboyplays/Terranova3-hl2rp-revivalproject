--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Human Lung"
ITEM.model = Model("models/gibs/humans/lung_gib.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Breathing is overrated."
ITEM.category = "Non-Approved Food";
ITEM.price = 6;
ITEM.restoreHealth = 6
ITEM.flag = "E"