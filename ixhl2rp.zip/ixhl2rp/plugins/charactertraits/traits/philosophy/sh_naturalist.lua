--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Naturalist";
TRAIT.opposite = "Transhumanist";
TRAIT.description = "Being human is a given, but keeping our humanity is a choice.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/naturalist.png";