--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Collectivist";
TRAIT.opposite = "Individualist";
TRAIT.description = "We're all in this together.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/tribal.png";