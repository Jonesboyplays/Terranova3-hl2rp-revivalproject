--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Sickly";
TRAIT.opposite = "Healthy";
TRAIT.description = "First to die when the medicine runs out.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/sickly.png";
TRAIT.negative = true;