
ITEM.name = "Pliers"
ITEM.model = Model("models/props_c17/tools_pliers01a.mdl")
ITEM.description = "Used for gripping something round like pipe or rod, twisting wires, or cutting wire."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 110
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique