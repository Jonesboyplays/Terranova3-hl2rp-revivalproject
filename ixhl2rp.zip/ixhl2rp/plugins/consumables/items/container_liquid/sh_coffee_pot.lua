--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Coffee Pot";
ITEM.model = "models/props_office/coffe_pot.mdl";
ITEM.width = 2;
ITEM.height = 2;
ITEM.description = "A large coffee pot with a glass carafe.";
ITEM.capacity = 1650