--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Volatile";
TRAIT.opposite = "Calm";
TRAIT.description = "Quick to anger and potentially dangerous.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/volatile.png";
TRAIT.negative = true;