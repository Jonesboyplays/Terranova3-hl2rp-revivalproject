--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Noodle Bowl"
ITEM.model = Model("models/ramen_noodels.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A classic steamy hot oriental meal."
ITEM.restoreHealth = 18
ITEM.category = "Civil-Approved Food";
ITEM.price = 15;
ITEM.flag = "f"