--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Adaptable";
TRAIT.opposite = "Stubborn";
TRAIT.description = "Sure, that works. Let's do that.";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/adaptable.png";
TRAIT.positive = true