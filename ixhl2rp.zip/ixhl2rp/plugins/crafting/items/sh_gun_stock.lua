
ITEM.name = "Gun Stock"
ITEM.model = Model("models/weapons/w_annabelle.mdl")
ITEM.description = "A weapon stock part, used in assembly crafting."
ITEM.width = 2
ITEM.height = 1
ITEM.price = 125
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique