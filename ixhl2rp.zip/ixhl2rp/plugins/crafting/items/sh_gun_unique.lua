
ITEM.name = "Unique Part"
ITEM.model = Model("models/weapons/w_crossbow.mdl")
ITEM.description = "Hard to find parts for the assembly of high-end firearms."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 500
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique