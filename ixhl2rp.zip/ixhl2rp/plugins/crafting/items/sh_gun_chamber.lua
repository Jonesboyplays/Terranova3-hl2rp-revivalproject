
ITEM.name = "Chambering Part"
ITEM.model = Model("models/gibs/manhack_gib03.mdl")
ITEM.description = "Chambering your weapon for your caliber."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 150
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique