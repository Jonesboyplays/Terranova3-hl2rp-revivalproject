--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Saelk"
ITEM.model = Model("models/mosi/fallout4/props/plant/glowingmushroom.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A long tendriled green mushroom from a Xen dimension."
ITEM.category = "Xen"
ITEM.price = 25;
ITEM.restoreHealth = 20
ITEM.flag = "X"