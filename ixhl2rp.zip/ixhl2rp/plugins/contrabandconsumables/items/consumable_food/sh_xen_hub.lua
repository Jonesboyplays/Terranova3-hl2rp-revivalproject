--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Hub"
ITEM.model = Model("models/mosi/fallout4/props/plant/hubflower.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A purple and blue flower from another dimension with matching characteristics."
ITEM.category = "Xen"
ITEM.price = 25;
ITEM.restoreHealth = 20
ITEM.flag = "X"