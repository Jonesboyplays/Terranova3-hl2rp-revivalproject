--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Individualist";
TRAIT.opposite = "Collectivist";
TRAIT.description = "I look out for Numero Uno.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/careerist.png";