--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Juice Box";
ITEM.model = "models/gibs/props_canteen/vm_snack19.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A childs juice box. Tastes like a long-gone fruit of some variety.";
ITEM.permit = "consumables";
ITEM.price = 4;
ITEM.capacity = 125
ITEM.restoreStamina = 4;
ITEM.category = "Non-Approved Drinks"