--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Kind";
TRAIT.opposite = "Cruel";
TRAIT.description = "Treat others how you want to be treated.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/kind.png";
TRAIT.positive = true