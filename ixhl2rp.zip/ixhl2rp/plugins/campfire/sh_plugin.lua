--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Campfire";
PLUGIN.description = "Adds a tinder box item which is used to create a campfire.";
PLUGIN.author = "RJ";

ix.util.Include("sv_hooks.lua");