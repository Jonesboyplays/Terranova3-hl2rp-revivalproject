--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.base = "base_legs";
ITEM.name = "Dress Pants";
ITEM.price = 43;
ITEM.model = "models/fty/items/suitpants.mdl"
ITEM.description = "A very expensive-looking set of dress pants with a polyester exterior, and a comfortable woolen interior. A tag on the inside of the of the pants reads 'CWU-Approved'."
ITEM.noBusiness = true
ITEM.bodyGroups = {
	["legs"] = 11
}