--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Lave"
ITEM.model = Model("models/mosi/fallout4/props/plant/bloodleaf.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A profoundly bizare red flower with an entoxicatingly beautiful smell."
ITEM.category = "Xen"
ITEM.price = 25;
ITEM.restoreHealth = 20
ITEM.flag = "X"