--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Approved Noodles";
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "A takeout shaped box with cooked hokkien 'egg' noodles and some light seasoning. It's still quite bad.";
ITEM.category = "Civil-Approved Food";
ITEM.permit = "consumables";
ITEM.price = 13;
ITEM.restoreHealth = 14;
ITEM.flag = "f"