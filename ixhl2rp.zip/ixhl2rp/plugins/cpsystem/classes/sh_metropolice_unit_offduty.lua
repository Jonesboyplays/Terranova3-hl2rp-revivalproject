--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author (zacharyenriquee@gmail.com).
--]]

CLASS.name = "Metropolice Unit Undercover";
CLASS.faction = FACTION_MPF;
CLASS.color = Color(150, 125, 100, 255);
CLASS_MPUH = CLASS.index