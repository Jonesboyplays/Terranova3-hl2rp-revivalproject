--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Bullsquid Meat"
ITEM.model = Model("models/gibs/xenians/mgib_02.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An uncooked bit of a mean spirited creature."
ITEM.category = "Non-Approved Food";
ITEM.restoreHealth = 15
ITEM.price = 10;
ITEM.flag = "E"