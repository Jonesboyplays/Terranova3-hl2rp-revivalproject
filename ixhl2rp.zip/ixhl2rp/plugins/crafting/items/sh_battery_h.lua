
ITEM.name = "Battery"
ITEM.model = Model("models/props_junk/junk_6vbattery.mdl")
ITEM.description = "A large battery box, containing a lot of charge."
ITEM.width = 2
ITEM.height = 2
ITEM.price = 100
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique