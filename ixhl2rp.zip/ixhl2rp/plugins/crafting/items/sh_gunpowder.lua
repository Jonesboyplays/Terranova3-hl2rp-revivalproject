
ITEM.name = "Gunpowder"
ITEM.model = Model("models/illusion/eftcontainers/gpgreen.mdl")
ITEM.description = "Earliest known chemical explosive. It consists of a mixture of sulfur, charcoal, and potassium nitrate."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique