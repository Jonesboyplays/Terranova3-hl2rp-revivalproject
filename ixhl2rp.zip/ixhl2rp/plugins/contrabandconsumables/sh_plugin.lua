--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Contraband Consumables";
PLUGIN.description = "Stores all the contraband consumable items that are used in TERRANOVA.";
PLUGIN.author = "Specky";
PLUGIN.maxLength = 512;


