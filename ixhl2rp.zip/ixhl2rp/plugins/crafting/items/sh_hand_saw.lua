
ITEM.name = "Saw"
ITEM.model = Model("models/mark2580/gtav/garage_stuff/grinder_01a.mdl")
ITEM.description = "A saw used to cut through plastics, wood and cardboard."
ITEM.width = 2
ITEM.height = 1
ITEM.price = 115
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique