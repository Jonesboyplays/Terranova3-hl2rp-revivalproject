--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Practical";
TRAIT.opposite = "Abstract";
TRAIT.description = "Sticks to what has proven to work.";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/practical.png";