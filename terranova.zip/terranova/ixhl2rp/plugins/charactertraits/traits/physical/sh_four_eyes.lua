--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Four Eyes";
TRAIT.opposite = "Eagle Eye";
TRAIT.description = "Can you bring it a little closer?";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/foureyes.png";
TRAIT.negative = true;