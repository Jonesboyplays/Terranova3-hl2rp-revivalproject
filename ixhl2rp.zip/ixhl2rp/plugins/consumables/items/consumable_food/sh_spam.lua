--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "SPAM";
ITEM.model = "models/warz/consumables/can_spam.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "An aluminium tin filled with SPAM. Whatever the fuck that is.";
ITEM.permit = "consumables";
ITEM.price = 10;
ITEM.category = "Civil-Approved Food";
ITEM.restoreHealth = 11;
ITEM.flag = "f"
ITEM.dropSound = {
"terranova/ui/cannedfood1.wav",
"terranova/ui/cannedfood2.wav",
"terranova/ui/cannedfood3.wav",
}