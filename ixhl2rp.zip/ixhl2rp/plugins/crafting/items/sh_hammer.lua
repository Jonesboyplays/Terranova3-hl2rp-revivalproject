
ITEM.name = "Hammer"
ITEM.model = Model("models/mark2580/gtav/garage_stuff/cs_hammer.mdl")
ITEM.description = "A sturdy hammer used to whack things."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 125
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique