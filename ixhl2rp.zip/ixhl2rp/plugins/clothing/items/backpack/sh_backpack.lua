--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Backpack";
ITEM.model = "models/fty/items/flynnisstinkylol.mdl"
ITEM.price = 25;
ITEM.description = "A small sling bag, useful for carrying things."
ITEM.outfitCategory = "bag";
ITEM.backgroundColor = Color(19, 72, 96, 100)
ITEM.flag = "a"
ITEM.bodyGroups = {
	["bag"] = 1
}