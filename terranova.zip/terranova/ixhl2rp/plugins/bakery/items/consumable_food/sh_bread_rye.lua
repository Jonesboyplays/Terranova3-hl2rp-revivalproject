--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Dark Rye Bread";
ITEM.model = "models/foodnhouseholditems/bread-3.mdl";
ITEM.width = 2;
ITEM.height = 1;
ITEM.description = "A loaf of delicious dark rye bread.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 18;
ITEM.restoreHealth = 20;
ITEM.flag = "b"