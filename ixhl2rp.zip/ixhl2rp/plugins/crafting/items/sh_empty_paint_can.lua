
ITEM.name = "Empty Paint Can"
ITEM.model = Model("models/props_junk/metal_paintcan001b.mdl")
ITEM.description = "An empty paint can."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5
ITEM.category = "Crafting"
ITEM.rarity = "Common"
ITEM.noBusiness = true
-- Junk Items Dont stack