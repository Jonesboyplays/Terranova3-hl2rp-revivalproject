
ITEM.name = "Screwdriver"
ITEM.model = Model("models/mark2580/gtav/garage_stuff/sdriver_01.mdl")
ITEM.description = "A handheld tool, used for screwing and unscrewing screws."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 90
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique