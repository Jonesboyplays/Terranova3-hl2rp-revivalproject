--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Fruit Bar";
ITEM.model = "models/gibs/props_canteen/vm_snack25.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A childs fruit bar for a typical lunchbox. Still tastes pretty good.";
ITEM.permit = "consumables";
ITEM.price = 3;
ITEM.restoreHealth = 3;
ITEM.category = "Non-Approved Food";
