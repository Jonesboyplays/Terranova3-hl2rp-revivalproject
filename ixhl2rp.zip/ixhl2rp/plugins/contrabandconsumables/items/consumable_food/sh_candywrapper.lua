--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Candy Wrapper";
ITEM.model = "models/gibs/props_canteen/vm_snack15.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "Some chocolate candy wrapper of some kind. Soft and melted. It's mushy, but still chocolate.";
ITEM.permit = "consumables";
ITEM.price = 4;
ITEM.restoreHealth = 4;
ITEM.category = "Non-Approved Food";