--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Eagle Eye";
TRAIT.opposite = "Four Eyes";
TRAIT.description = "Did you guys see that?";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/eagleeye.png";
TRAIT.positive = true