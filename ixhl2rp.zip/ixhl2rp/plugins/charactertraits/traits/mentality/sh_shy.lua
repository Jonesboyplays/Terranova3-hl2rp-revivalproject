--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Shy";
TRAIT.opposite = "Outgoing";
TRAIT.description = "I think I'll stay at home.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/shy.png";
TRAIT.negative = true;