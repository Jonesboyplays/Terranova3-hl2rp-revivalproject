ITEM.name = "Book"
ITEM.description = "A book that you can write on."
ITEM.model = Model("models/props_c17/paper01.mdl")