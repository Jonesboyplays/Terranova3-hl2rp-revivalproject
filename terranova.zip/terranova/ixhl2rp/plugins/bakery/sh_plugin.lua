--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author (zacharyenriquee@gmail.com).
--]]

PLUGIN.name = "Bakery";
PLUGIN.description = "Adds numerous pastries and bread items.";
PLUGIN.author = "Blackfire";