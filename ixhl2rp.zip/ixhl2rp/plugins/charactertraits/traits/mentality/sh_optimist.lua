--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Optimist";
TRAIT.opposite = "Pessimist";
TRAIT.description = "Every cloud has a silver lining.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/gleeful.png";
TRAIT.positive = true