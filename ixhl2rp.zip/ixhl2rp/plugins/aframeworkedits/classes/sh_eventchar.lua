CLASS.name = "Event Character"
CLASS.faction = FACTION_EVENT_CHAR
CLASS.isDefault = true
CLASS.color = Color(150, 125, 100, 255);

CLASS_EVENTCHAR = CLASS.index