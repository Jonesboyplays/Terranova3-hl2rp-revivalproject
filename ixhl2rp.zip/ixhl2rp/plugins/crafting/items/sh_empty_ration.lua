
ITEM.name = "Ration Packaging"
ITEM.model = Model("models/weapons/w_packate.mdl")
ITEM.description = "Ration packaging containing a vacuum seal."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- CWU Combine item