--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Plain Bagel";
ITEM.model = "models/foodnhouseholditems/bagel1.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A beautiful hand crafted all American New York bagel.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 15;
ITEM.restoreHealth = 7;
ITEM.flag = "b"