--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Human Liver"
ITEM.model = Model("models/gibs/humans/liver_gib.mdl")
ITEM.width = 1
ITEM.height = 2
ITEM.description = "Used to be lively. Dead now."
ITEM.category = "Non-Approved Food";
ITEM.price = 7;
ITEM.restoreHealth = 7
ITEM.flag = "E"