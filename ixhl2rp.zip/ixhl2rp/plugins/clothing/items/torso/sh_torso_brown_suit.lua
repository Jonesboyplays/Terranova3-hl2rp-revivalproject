--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.base = "base_torso";
ITEM.name = "Brown Dinner Jacket with Tie";
ITEM.model = "models/fty/items/suitjacket.mdl"
ITEM.price = 50;
ITEM.description = "A fancy looking brown dinner jacket with an orange, white and black striped tie.";
ITEM.noBusiness = true
ITEM.bodyGroups = {
	["torso"] = 13
}