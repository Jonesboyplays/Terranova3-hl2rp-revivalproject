# ix-flashlight
A flashlight item for Helix. Released to the public domain.

## Installation
- Download the zip
- Extract it into your Schema's plugin folder
