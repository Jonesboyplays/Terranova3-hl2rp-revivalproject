--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Cynical";
TRAIT.opposite = "Optimistic";
TRAIT.description = "I doubt it.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/cynical.png";
TRAIT.negative = true;