--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Generic Meat"
ITEM.model = Model("models/kek1ch/meat_pseudodog.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A can of mysterious meat, the only way to know what it was is if you cooked it yourself."
ITEM.category = "Non-Approved Food";
ITEM.price = 20;
ITEM.restoreHealth = 25
ITEM.flag = "E"