--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Healthy";
TRAIT.opposite = "Sickly";
TRAIT.description = "Consistent apple consumption has created a superhuman.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/healthy.png";
TRAIT.positive = true