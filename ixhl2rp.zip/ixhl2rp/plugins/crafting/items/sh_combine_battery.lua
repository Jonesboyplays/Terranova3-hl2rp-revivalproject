
ITEM.name = "Combine Battery"
ITEM.model = Model("models/props_hla/combine/battery.mdl")
ITEM.description = "A combine battery, it's potential is unknown."
ITEM.width = 1
ITEM.height = 2
ITEM.price = 150
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack