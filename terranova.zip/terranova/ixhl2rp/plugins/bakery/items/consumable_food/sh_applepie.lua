--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Apple Pie";
ITEM.model = "models/foodnhouseholditems/pie.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A deliciously sweet apple pie with crispy golden brown pie crust.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 25;
ITEM.restoreHealth = 29;
ITEM.flag = "b"