--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Aster"
ITEM.model = Model("models/mosi/fallout4/props/plant/asterflower.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A strange Xen flower with a wide purple top and a strange smell."
ITEM.category = "Xen"
ITEM.price = 25;
ITEM.restoreHealth = 20
ITEM.flag = "X"