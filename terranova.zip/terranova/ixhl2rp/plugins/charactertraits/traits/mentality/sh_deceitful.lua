--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Deceitful";
TRAIT.opposite = "Honest";
TRAIT.description = "I didn't take from the cookie jar. He did.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/deceitful.png";
TRAIT.negative = true;