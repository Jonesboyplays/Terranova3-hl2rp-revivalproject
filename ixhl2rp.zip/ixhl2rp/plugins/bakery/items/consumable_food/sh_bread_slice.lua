--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Slice of Bread";
ITEM.model = "models/foodnhouseholditems/bread_slice.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A slice of delicious bread.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 6;
ITEM.restoreHealth = 4;
ITEM.flag = "b"