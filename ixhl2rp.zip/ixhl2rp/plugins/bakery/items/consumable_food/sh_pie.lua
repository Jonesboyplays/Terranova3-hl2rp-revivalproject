--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Pie";
ITEM.model = "models/griim/foodpack/pie.mdl";
ITEM.width = 2;
ITEM.height = 1;
ITEM.description = "Crusted delight with something sweet.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 19;
ITEM.restoreHealth = 19;
ITEM.flag = "b"