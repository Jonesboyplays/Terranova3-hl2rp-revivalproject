--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Dye";
ITEM.model = "models/mark2580/gtav/garage_stuff/plastic_canister.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "Desc Here.";
ITEM.price = 25;
ITEM.capacity = 200
ITEM.noBusiness = true
ITEM.category = "Liquid";
