--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Wholegrain Bread";
ITEM.model = "models/foodnhouseholditems/bread-4.mdl";
ITEM.width = 2;
ITEM.height = 1;
ITEM.description = "A loaf of delicious wholegrain bread.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 22;
ITEM.restoreHealth = 20;
ITEM.flag = "b"