--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Narcissist";
TRAIT.opposite = "Selfless";
TRAIT.description = "It's for me, and about me, baby.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/narcissist.png";
TRAIT.negative = true;