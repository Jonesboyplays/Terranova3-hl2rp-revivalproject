--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Stubborn";
TRAIT.opposite = "Adaptable";
TRAIT.description = "My way, or the highway.";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/stubborn.png";
TRAIT.negative = true;