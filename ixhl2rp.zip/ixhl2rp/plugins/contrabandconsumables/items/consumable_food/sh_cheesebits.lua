--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Cheese Bits Packet";
ITEM.model = "models/gibs/props_canteen/vm_snack02.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A packet of mind numbing expired cheese-bits.";
ITEM.permit = "consumables";
ITEM.price = 2;
ITEM.restoreHealth = 2;
ITEM.category = "Non-Approved Food";