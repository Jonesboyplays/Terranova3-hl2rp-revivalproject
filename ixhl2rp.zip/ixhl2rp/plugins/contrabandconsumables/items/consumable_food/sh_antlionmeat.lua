--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Antlion Meat"
ITEM.model = Model("models/gibs/antlion_gib_small_2.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An uncooked small piece of a large burrowing alien insect. Definitely has a lot of protein."
ITEM.category = "Non-Approved Food";
ITEM.price = 5;
ITEM.restoreHealth = 5
ITEM.flag = "E"