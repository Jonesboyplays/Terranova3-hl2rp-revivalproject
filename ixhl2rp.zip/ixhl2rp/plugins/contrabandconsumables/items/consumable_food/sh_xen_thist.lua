--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Thist"
ITEM.model = Model("models/mosi/fallout4/props/plant/thistle.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A Xen flora that flourishes in a variety of colours depending on it's temperature."
ITEM.category = "Xen"
ITEM.price = 25;
ITEM.restoreHealth = 20
ITEM.flag = "X"