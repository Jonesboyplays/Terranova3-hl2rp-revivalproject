
ITEM.name = "Cables"
ITEM.model = Model("models/illusion/eftcontainers/wires.mdl")
ITEM.description = "Some metal cables."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 15
ITEM.category = "Crafting"
ITEM.rarity = "Common"
ITEM.noBusiness = true
ITEM.maxStack = 15;
ITEM.defaultStack = 1;