--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Human Eye"
ITEM.model = Model("models/gibs/humans/eye_gib.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Optical illusion. It's chicken."
ITEM.category = "Non-Approved Food";
ITEM.restoreHealth = 3
ITEM.price = 3;
ITEM.flag = "E"