--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Pretzel";
ITEM.model = "models/foodnhouseholditems/pretzel.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A salty, chewy treat.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 3;
ITEM.restoreHealth = 3;
ITEM.flag = "b"