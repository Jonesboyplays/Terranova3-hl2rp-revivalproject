--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Thick Skinned";
TRAIT.opposite = "Thin Skinned";
TRAIT.description = "I didn't hear no bell.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/thickskinned.png";
TRAIT.positive = true