
ITEM.name = "Empty Can"
ITEM.model = Model("models/props_junk/garbage_metalcan001a.mdl")
ITEM.description = "An empty can."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5
ITEM.category = "Crafting"
ITEM.rarity = "Common"
ITEM.noBusiness = true
-- Junk Items Dont stack