--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Cruel";
TRAIT.opposite = "Kind";
TRAIT.description = "Gotta crack a few eggs to make an omelette.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/cruel.png";
TRAIT.negative = true;