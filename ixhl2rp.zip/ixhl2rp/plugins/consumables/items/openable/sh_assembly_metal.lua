ITEM.name = "Designated Recyclables Box"
ITEM.model = Model("models/props_junk/cardboard_box003a.mdl")
ITEM.description = "A large box labled with the recycle symbol, it contains junk items for refinement."
ITEM.noBusiness = true
ITEM.contains = {
    [1] = {
        uniqueID = "scrap_metal",
        amount = 2,
        data = {}
    }
}