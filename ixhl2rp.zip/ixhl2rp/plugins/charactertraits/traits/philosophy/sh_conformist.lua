--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Conformist";
TRAIT.opposite = "Rebellious";
TRAIT.description = "Don't bite the hand that feeds you.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/passive.png";