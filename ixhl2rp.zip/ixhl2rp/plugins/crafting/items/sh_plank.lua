
ITEM.name = "Plank"
ITEM.model = Model("models/props_debris/wood_board04a.mdl")
ITEM.description = "A full wooden plank."
ITEM.width = 1
ITEM.height = 2
ITEM.price = 40
ITEM.category = "Crafting"
ITEM.rarity = "Rare"
ITEM.noBusiness = true
-- No stack Unique