--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Flask";
ITEM.model = "models/misery/flask.mdl";
ITEM.width = 1;
ITEM.height = 2;
ITEM.description = "A medium sized cylindrical metallic flask from pre-war.";
ITEM.capacity = 600