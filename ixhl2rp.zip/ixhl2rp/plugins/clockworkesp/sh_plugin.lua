--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Clockwork ESP";
PLUGIN.description = "Converts the clockwork admin esp to helix.";
PLUGIN.author = "Adolphus";

ix.util.Include("cl_hooks.lua")
