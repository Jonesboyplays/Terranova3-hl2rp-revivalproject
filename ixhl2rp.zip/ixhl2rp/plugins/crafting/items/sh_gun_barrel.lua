
ITEM.name = "Barrel Part"
ITEM.model = Model("models/props_lab/pipesystem03d.mdl")
ITEM.description = "A simple barrel tubing for a firearm."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 90
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique