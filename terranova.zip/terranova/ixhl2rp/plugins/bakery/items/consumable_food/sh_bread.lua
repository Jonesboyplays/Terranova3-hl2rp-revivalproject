--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Approved Bread";
ITEM.model = "models/kek1ch/dev_bred.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "Fresh, gross Union bread. It tastes of its texture. Grit.";
ITEM.permit = "consumables";
ITEM.category = "Civil-Approved Food";
ITEM.price = 6;
ITEM.restoreHealth = 10;
ITEM.rarity = "Rare"
ITEM.flag = "f"