--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Bright";
TRAIT.opposite = "Dull";
TRAIT.description = "Grasps concepts faster than most.";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/bright.png";
TRAIT.positive = true