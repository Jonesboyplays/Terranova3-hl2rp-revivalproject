--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Weak";
TRAIT.opposite = "Strong";
TRAIT.description = "Never had the makings of a varisty athlete.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/weak.png";
TRAIT.negative = true;