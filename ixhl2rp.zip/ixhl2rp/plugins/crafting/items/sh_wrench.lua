ITEM.name = "Wrench"
ITEM.model = Model("models/props_c17/tools_wrench01a.mdl")
ITEM.description = "Used to tighten or loosen nuts and bolts."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 215
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique