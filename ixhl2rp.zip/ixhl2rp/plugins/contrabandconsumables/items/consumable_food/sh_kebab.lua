--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Kebab"
ITEM.model = Model("models/kek1ch/meat_tushkano.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A freshly made kebab. Smells amazing and tastes even better."
ITEM.category = "Non-Approved Food";
ITEM.restoreHealth = 15
ITEM.price = 15;
ITEM.flag = "E"
