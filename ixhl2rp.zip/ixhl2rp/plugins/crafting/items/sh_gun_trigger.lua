
ITEM.name = "Trigger Part"
ITEM.model = Model("models/props_c17/utilityconnecter005.mdl")
ITEM.description = "Parts for setting up the trigger for a firearm."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 40
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique