--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Transhumanist";
TRAIT.opposite = "Naturalist";
TRAIT.description = "Immortality is in our reach.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/transhumanist.png";