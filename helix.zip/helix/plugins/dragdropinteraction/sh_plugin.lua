--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Drag Drop Interaction";
PLUGIN.description = "Adds a drag and drop interaction system to the inventory that allows items to call special functions when dragged over each other.";
PLUGIN.author = "Adolphus";

ix.util.Include("sv_hooks.lua")