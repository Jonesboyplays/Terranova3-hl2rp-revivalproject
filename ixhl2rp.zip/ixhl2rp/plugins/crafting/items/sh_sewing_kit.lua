
ITEM.name = "Sewing Kit"
ITEM.model = Model("models/zworld_health/healkit.mdl")
ITEM.description = "Various tools for cutting, stitching or tailoring fabrics and clothes."
ITEM.width = 2
ITEM.height = 2
ITEM.price = 150
ITEM.flag = "M"
ITEM.category = "Tools"
-- No stack Unique
