
ITEM.name = "Bolts"
ITEM.model = Model("models/illusion/eftcontainers/nuts.mdl")
ITEM.description = "A handful of bolts in a box."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 25
ITEM.category = "Crafting"
ITEM.rarity = "Common"
ITEM.noBusiness = true
ITEM.maxStack = 10;
ITEM.defaultStack = 1;