--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "PET Bottle";
ITEM.model = "models/warz/consumables/water_l.mdl";
ITEM.width = 1;
ITEM.height = 2;
ITEM.description = "A large plastic bottle designed for holding liquid.";
ITEM.capacity = 1000