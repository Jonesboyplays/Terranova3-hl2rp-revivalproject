--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Chemical Base";
ITEM.model = "models/mark2580/gtav/garage_stuff/oilbot03.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "Desc Here.";
ITEM.price = 25;
ITEM.capacity = 375
ITEM.noBusiness = true
ITEM.category = "Liquid";
