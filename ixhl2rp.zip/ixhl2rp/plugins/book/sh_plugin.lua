
PLUGIN.name = "Book Write/Read"
PLUGIN.description = "Adds the ability to write and read books."
PLUGIN.author = "`theHandgun"
PLUGIN.characterLimit = 15000
PLUGIN.characterLimitPerPage = 323

ix.util.Include("sv_hooks.lua")
ix.util.Include("cl_hooks.lua")
