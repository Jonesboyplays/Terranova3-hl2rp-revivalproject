
ITEM.name = "REDACTED ITEM RM"
ITEM.model = Model("models/props_lab/pipesystem03a.mdl")
ITEM.description = "This item is no longer being used and will be deleted from the game in 2 updates. You can turn this in for money at the trash compactor"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 5
ITEM.noBusiness = true
-- Phase out