--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Human Flesh"
ITEM.model = Model("models/kek1ch/raw_dog.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "A meat that can be cooked and eaten."
ITEM.category = "Non-Approved Food";
ITEM.price = 5;
ITEM.restoreHealth = 5
ITEM.flag = "E"