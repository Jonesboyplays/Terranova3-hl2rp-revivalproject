--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Dull";
TRAIT.opposite = "Bright";
TRAIT.description = "Explanations may need to be repeated.";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/dull.png";
TRAIT.negative = true;