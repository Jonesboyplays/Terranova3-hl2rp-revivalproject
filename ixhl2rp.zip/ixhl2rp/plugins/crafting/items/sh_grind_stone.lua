
ITEM.name = "Grind Stone"
ITEM.model = Model("models/props_junk/rock001a.mdl") -- Needs changing
ITEM.description = "A sturdy hardened stone used to fine things down to a sharp edge or point."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 110
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique