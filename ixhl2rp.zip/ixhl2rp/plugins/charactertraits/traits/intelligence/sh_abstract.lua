--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Abstract";
TRAIT.opposite = "Practical";
TRAIT.description = "Applicability takes backseat to theoretical..";
TRAIT.category = "Intelligence";
TRAIT.icon = "materials/terranova/ui/traits/abstract.png";