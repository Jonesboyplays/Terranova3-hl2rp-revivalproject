--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Brave";
TRAIT.opposite = "Cowardly";
TRAIT.description = "Fear is the ultimate foe.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/brave.png";
TRAIT.positive = true