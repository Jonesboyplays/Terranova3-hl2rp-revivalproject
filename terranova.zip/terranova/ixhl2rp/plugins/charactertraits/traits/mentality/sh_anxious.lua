--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Anxious";
TRAIT.opposite = "Easygoing";
TRAIT.description = "I don't know what's going on, but I don't like it!";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/anxious.png";
TRAIT.negative = true;