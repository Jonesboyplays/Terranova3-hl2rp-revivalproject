--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author (zacharyenriquee@gmail.com).
--]]

local PLUGIN = PLUGIN
PLUGIN.pacData = PLUGIN.pacData or {}
PLUGIN.pacData.unlit = {
    [1] = {
        ["children"] = {
            [1] = {
                ["children"] = {
                },
                ["self"] = {
                    ["Skin"] = 0,
                    ["Invert"] = false,
                    ["LightBlend"] = 1,
                    ["CellShade"] = 0,
                    ["OwnerName"] = "self",
                    ["AimPartName"] = "",
                    ["IgnoreZ"] = false,
                    ["AimPartUID"] = "",
                    ["Passes"] = 1,
                    ["Name"] = "",
                    ["NoTextureFiltering"] = false,
                    ["DoubleFace"] = false,
                    ["PositionOffset"] = Vector(0, 0, 0),
                    ["IsDisturbing"] = false,
                    ["Fullbright"] = false,
                    ["EyeAngles"] = false,
                    ["DrawOrder"] = 0,
                    ["TintColor"] = Vector(0, 0, 0),
                    ["UniqueID"] = "2381412624",
                    ["Translucent"] = false,
                    ["LodOverride"] = -1,
                    ["BlurSpacing"] = 0,
                    ["Alpha"] = 1,
                    ["Material"] = "",
                    ["UseWeaponColor"] = false,
                    ["UsePlayerColor"] = false,
                    ["UseLegacyScale"] = false,
                    ["Bone"] = "mouth",
                    ["Color"] = Vector(255, 255, 255),
                    ["Brightness"] = 1,
                    ["BoneMerge"] = false,
                    ["BlurLength"] = 0,
                    ["Position"] = Vector(0.92388153076172, 0.64091873168945, -0.26725006103516),
                    ["AngleOffset"] = Angle(0, 0, 0),
                    ["AlternativeScaling"] = false,
                    ["Hide"] = false,
                    ["OwnerEntity"] = false,
                    ["Scale"] = Vector(1, 1, 1),
                    ["ClassName"] = "model",
                    ["EditorExpand"] = true,
                    ["Size"] = 0.775,
                    ["ModelFallback"] = "",
                    ["Angles"] = Angle(5.7427682876587, 7.837429523468, -27.594648361206),
                    ["TextureFilter"] = 3,
                    ["Model"] = "models/phycinnew.mdl",
                    ["BlendMode"] = "",
                },
            },
        },
        ["self"] = {
            ["DrawOrder"] = 0,
            ["UniqueID"] = "2515612144",
            ["AimPartUID"] = "",
            ["Hide"] = false,
            ["Duplicate"] = false,
            ["ClassName"] = "group",
            ["OwnerName"] = "self",
            ["IsDisturbing"] = false,
            ["Name"] = "Ciggarette",
            ["EditorExpand"] = true,
        },
    },    
}