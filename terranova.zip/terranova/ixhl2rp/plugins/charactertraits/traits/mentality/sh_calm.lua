--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Calm";
TRAIT.opposite = "Volatile";
TRAIT.description = "Tranquil as a Hindu cow.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/calm.png";