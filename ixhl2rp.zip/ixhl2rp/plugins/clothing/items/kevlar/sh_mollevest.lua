--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Molle Vest";
ITEM.price = 165;
ITEM.model = "models/fty/items/mollevest.mdl"
ITEM.description = "Decent bullet resistant vest likely recovered from oldworld military salvage."
ITEM.flag = "Z"
ITEM.bodyGroups = {
	["kevlar"] = 5
}
ITEM.category = "Clothing - Contraband";
ITEM.noBusiness = true