--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Honest";
TRAIT.opposite = "Deceitful";
TRAIT.description = "We're gonna have to hand these in.";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/honest.png";