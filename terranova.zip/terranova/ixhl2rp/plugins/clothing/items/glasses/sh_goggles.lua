--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.base = "base_glasses";
ITEM.name = "Goggles";
ITEM.model = "models/fty/items/goggles.mdl"
ITEM.flag = "A"
ITEM.category = "Clothing - MCS";
ITEM.price = 15
ITEM.description = "A pair of Mad-Max looking goggles befit for the Texan Lone Ranger."
ITEM.bodyGroups = {
	["glasses"] = 2
}