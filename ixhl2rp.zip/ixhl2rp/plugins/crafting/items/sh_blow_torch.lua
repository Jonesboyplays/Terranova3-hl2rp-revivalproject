
ITEM.name = "Blow Torch"
ITEM.model = Model("models/mark2580/gtav/garage_stuff/blowtorch.mdl")
ITEM.description = "A fuel-burning tool used for applying flame and heat to various applications, usually metalworking."
ITEM.width = 2
ITEM.height = 1
ITEM.price = 115
ITEM.category = "Tools"
ITEM.flag = "M"
-- No stack Unique