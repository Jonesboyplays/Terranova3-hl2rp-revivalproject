--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Potato";
ITEM.model = "models/griim/foodpack/potato.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "An earthy, grown potato. If you can find a peeler, you could make many things with this wonderful vegetable.";
ITEM.permit = "consumables";
ITEM.price = 5;
ITEM.restoreHealth = 5;
ITEM.category = "Non-Approved Food";