--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Trusting";
TRAIT.opposite = "Paranoid";
TRAIT.description = "Why would I lock my doors?";
TRAIT.category = "Mentality";
TRAIT.icon = "materials/terranova/ui/traits/trusting.png";