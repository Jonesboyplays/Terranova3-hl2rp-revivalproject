
ITEM.name = "Water Filter"
ITEM.model = Model("models/illusion/eftcontainers/waterfilter.mdl")
ITEM.description = "Small portable filter designed to purify liquids for consumption."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 75
ITEM.category = "Tools"
ITEM.noBusiness = true
-- No stack Unique