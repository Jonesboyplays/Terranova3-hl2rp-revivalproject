--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Headcrab Meat"
ITEM.model = Model("models/gibs/humans/sgib_03.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "An uncooked piece of a head-hugging creature."
ITEM.category = "Non-Approved Food";
ITEM.price = 5;
ITEM.restoreHealth = 5
ITEM.flag = "E"