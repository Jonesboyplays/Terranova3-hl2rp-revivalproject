--[[
© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Tekel Cigarette"
ITEM.model = Model("models/phycinnew.mdl")
ITEM.width = 1
ITEM.height = 1
ITEM.description = "Delicious, authentic lung-killing addiction sticks. There's a little branding on the filter of the cigarette, reading 'TEKEL'."
ITEM.category = "Contraband"
ITEM.price = 5;
ITEM.flag = "G"
ITEM.time = 300