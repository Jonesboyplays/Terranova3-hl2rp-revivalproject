
ITEM.name = "Magazine"
ITEM.model = Model("models/weapons/tnmmod/w_pistol_magazine.mdl")
ITEM.description = "A magazine clip used to store ammunition, this one is loaded."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 75
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique