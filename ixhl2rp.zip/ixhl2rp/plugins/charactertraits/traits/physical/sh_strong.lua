--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Strong";
TRAIT.opposite = "Weak";
TRAIT.description = "Harder, better, faster, stronger.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/strong.png";
TRAIT.positive = true