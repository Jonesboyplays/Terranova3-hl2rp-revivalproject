--[[
	© 2017 Terra Nova do not use, share, re-distribute or modify without 
	permission of its author(zacharyenriquee@gmail.com) (Adolphus). 
--]]
include("shared.lua")

-- Called when the entity should draw.
function ENT:Draw() self:DrawModel(); end;