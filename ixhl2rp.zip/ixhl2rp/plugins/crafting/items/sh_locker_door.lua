
ITEM.name = "REDACTED LD"
ITEM.model = Model("models/props_lab/lockerdoorleft.mdl")
ITEM.description = "This item is no longer being used and will be deleted from the game in 2 updates. You can sell this at the trash compactor."
ITEM.width = 1
ITEM.height = 2
ITEM.price = 5
ITEM.noBusiness = true
-- Phase Out