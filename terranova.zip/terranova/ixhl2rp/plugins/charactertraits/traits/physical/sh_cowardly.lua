--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Cowardly";
TRAIT.opposite = "Brave";
TRAIT.description = "Live to fight another day.";
TRAIT.category = "Physical";
TRAIT.icon = "materials/terranova/ui/traits/cowardly.png";
TRAIT.negative = true;