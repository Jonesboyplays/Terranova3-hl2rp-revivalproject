--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
    without permission of its author.
--]]

TRAIT.name = "Rebellious";
TRAIT.opposite = "Conformist";
TRAIT.description = "Never take it lying down.";
TRAIT.category = "Philosophy";
TRAIT.icon = "materials/terranova/ui/traits/rebellious.png";