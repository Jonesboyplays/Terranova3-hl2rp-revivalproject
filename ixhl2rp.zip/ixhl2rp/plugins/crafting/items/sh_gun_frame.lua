
ITEM.name = "Gun Frame Part"
ITEM.model = Model("models/weapons/w_eq_eholster.mdl")
ITEM.description = "Various parts of a weapons frame used to assemble guns."
ITEM.width = 2
ITEM.height = 1
ITEM.price = 225
ITEM.category = "Crafting"
ITEM.noBusiness = true
-- No stack Unique