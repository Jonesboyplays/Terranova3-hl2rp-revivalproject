--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Water Bottle";
ITEM.model = "models/warz/consumables/water_l.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A bottle of old water. Better than what Breen has, atleast.";
ITEM.permit = "consumables";
ITEM.category = "Non-Approved Drinks";
ITEM.price = 12;
ITEM.capacity = 500
ITEM.restoreStamina = 20;