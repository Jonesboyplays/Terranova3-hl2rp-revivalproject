--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Croissant";
ITEM.model = "models/foodnhouseholditems/croissant.mdl";
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "A delicious, buttery, flakey, French croissant.";
ITEM.permit = "consumables";
ITEM.category = "Bread";
ITEM.price = 19;
ITEM.restoreHealth = 13;
ITEM.flag = "b"