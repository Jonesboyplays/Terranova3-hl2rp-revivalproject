--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Cadburry Hazel Chocolate";
ITEM.model = "models/cadbury2/cadbury2.mdl";
ITEM.width = 1;
ITEM.height	= 1;
ITEM.description = "Classic Australian chocolate spotted with Hazelnut eaten by only the most god-like people.";
ITEM.permit = "consumables";
ITEM.category = "Australian"
ITEM.price = 20;
ITEM.restoreHealth = 5;
ITEM.flag = "z"