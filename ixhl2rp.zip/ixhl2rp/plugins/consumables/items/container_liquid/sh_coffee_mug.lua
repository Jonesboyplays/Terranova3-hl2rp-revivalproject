--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

ITEM.name = "Coffee Mug";
ITEM.description = "Yellow ceramic mug. The bottom is stained with coffee.";
ITEM.capacity = 150